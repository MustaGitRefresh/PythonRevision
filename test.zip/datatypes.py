# # b = bytes(0b110110)
# b = bytes(25623)
# a = memoryview(b)  # it displays the memory address of the byte object
# print(a)
# a = [10, 12, 45]
# b = bytearray(a)
# b = bytes(a)  # TypeError: 'bytes' object does not support item assignment
# b[2] = 15
# for i in b:
#     print(i)

